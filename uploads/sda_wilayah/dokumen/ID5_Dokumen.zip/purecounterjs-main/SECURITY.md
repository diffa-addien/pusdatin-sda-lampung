# Security Policy

## Supported Versions

These are the versions of the project being support with security fixes.

| Version | Supported          |
| ------- | ------------------ |
| 1.x.x  | :white_check_mark: |

## Reporting a Vulnerability

Please report any security vulnerability to: [stig@rexdigital.group](mailto:stig@rexdigital.group).
